# Changes

## 0.1.40

- Supprime les gestionnaires d'outils Git redondants fournis nativement par le module Node tout en conservant le panneau bureau et le badge.

## 0.1.39

- Signale le code d’erreur lorsqu’une action Git échoue.

## 0.1.38

- Masque le badge des modifications si Git n’est pas installé sur l’hôte.

## 0.1.36

- Icônes au trait rétablies dans la navigation et les outils

## 0.1.35

- Nouvelle icône du plugin

## 0.1.34

- Actualise les branches de conversation après une modification des références, sans analyser l’état des fichiers
- Empêche les anciennes lectures de remplacer les nouveaux choix
- Distingue les branches locales et distantes de même nom lors de la création d’une conversation dérivée

## 0.1.28

- Sélectionner les branches locales et distantes dans une fenêtre contextuelle avec indication de la branche actuelle
- Conserver la navigation entre branches dans la fenêtre contextuelle et réutiliser les formulaires de création

## 0.1.27

- Conserver le décalage des lignes dans les curseurs d’historique pour éviter de répéter les comparaisons de chemins

## 0.1.18

- Conserver la page normale pendant le chargement des données initiales

## 0.1.9

- Ajout de la catégorie et de la couleur du catalogue
- Ajout des noms d’outils traduits
